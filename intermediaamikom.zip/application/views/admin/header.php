<script src="<?= base_url(); ?>assets/admin/js/require.min.js"></script>
<script>
    requirejs.config({
        baseUrl: '<?= base_url(); ?>'
    });
</script>

<script src="<?= base_url(); ?>assets/admin/js/dashboard.js"></script>
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/admin/css/dashboard.css"/>
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/admin/plugins/charts-c3/plugin.css"/>
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/admin/plugins/summernote/summernote.css"/>
<!--<noscript>
<style>html{display:none;}</style>
Sorry, your browser does not support JavaScript!
</noscript>-->


