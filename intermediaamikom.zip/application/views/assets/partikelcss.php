
    <link rel="stylesheet" href="<?php echo base_url()?>assets/user/main.css">
    <link href="<?php echo base_url()?>assets/user/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url()?>assets/user/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,600' rel='stylesheet' type='text/css'>

    <!--[if IE]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


    <script type="text/javascript">

        //ddsmoothmenu.init({
          //mainmenuid: "templatemo_flicker", //menu DIV id
            //orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
            //classname: 'ddsmoothmenu', //class added to menu's outer DIV
            //customtheme: ["#1c5a80", "#18374a"],
            //contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
       // });

    </script>
