

<!-- particle js -->

<script src="<?php echo base_url()?>assets/user/js/TweenLite.min.js"></script>
<script src="<?php echo base_url()?>assets/user/js/EasePack.min.js"></script>

<script src="<?php echo base_url()?>assets/user/js/spiral.js"></script>


<script type="text/javascript">
    <!--
        function toggle_visibility(id) {
    var e = document.getElementById(id);
    if (e.style.display === 'block') {
    e.style.display = 'none';
    $('#togg').text('show footer');
    } else {
    e.style.display = 'block';
    $('#togg').text('hide footer');
    }
    }
    //-->
</script>
