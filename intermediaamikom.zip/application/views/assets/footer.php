 <!--
            ==================================================
            Footer Section Start
            ================================================== -->
          <!-- /#footer -->

          <footer class="footer" data-background-color="black">
                    <div class="container">
                        <nav>
                            <ul>
                                <li>
                                    <a href="./executive">
                                        Executive Area
                                    </a>
                                </li>
                                <li>
                                    <a href="./about">
                                        About Us
                                    </a>
                                </li>
                            
                                <li class="nav-item">
                                    <a class="nav-link" rel="tooltip" title="Follow us on Instagram" data-placement="bottom" href="https://www.instagram.com/intermedia_amikompwt/" target="_blank">
                                        <i class="fa fa-instagram"></i>
                                    
                                    </a>
                                </li>
                            </ul>
                        </nav>
                        <div class="copyright">
                            &copy; 2011 -
                            <script>
                                document.write(new Date().getFullYear())
                            </script>. Designed and Developed by
                            <a href="#" target="_blank">Intermedia Dev.</a>
                        </div>
                    </div>
                </footer>