<?php $this->load->view('desain/partikelcss'); ?>
<header id="main-header" class="large-header">
        <canvas id="demo-canvas"></canvas>
        <div class="main-title ">
          <section class="moduler wrapper_404">
              <div class="container">
                  <div class="row">
                      <div class="col-md-12">
                        <div class="form-group row">
                          <label for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                          <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputPassword" placeholder="Nama">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="inputPassword" class="col-sm-2 col-form-label">email</label>
                          <div class="col-sm-10">
                            <input type="email" class="form-control" id="inputPassword" placeholder="Nama">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="inputPassword" class="col-sm-2 col-form-label">NoHp</label>
                          <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputPassword" placeholder="Nama">
                          </div>

                        </div>
                        <div class="form-group row">
                          <label for="inputPassword" class="col-sm-2 col-form-label">CV</label>
                          <div class="col-sm-10">
                            <input type="file" class="form-control" id="inputPassword" placeholder="Nama">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="inputPassword" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                          <div class="col-sm-10">
                            <select id="inputState" class="form-control">
                              <option selected>Choose...</option>
                              <option>...</option>
                            </select>
                          </div>
                        </div>
                      </div>
                  </div>
              </div>
          </section>

          </div>

 </header>
<?php $this->load->view('desain/particlejs'); ?>
