<?php $this->load->view('assets/partikelcss'); ?>
<header id="main-header" class="large-header">
        <canvas id="demo-canvas"></canvas>
        <div class="main-title ">
            <center><img class="wow fadeInDown" wow-duration="500ms" data-wow-delay=".3s" src="<?php echo base_url()?>assets/user/img/logo.png"></center>
            <h2 align="center" class="wow fadeInDown" wow-duration="500ms" data-wow-delay=".5s"><b><font color="grey">INTERMEDIA</font></h2>
            <h4 align="center" class="wow fadeInDown" wow-duration="500ms" data-wow-delay=".8s" ><b><font color="green">#WE ARE FAMILY</font></b></h4>
        </div>
 </header>
<?php $this->load->view('assets/particlejs'); ?>
